/**
 * helpers.c
 *
 * Computer Science 50
 * Problem Set 3
 *
 * Helper functions for Problem Set 3.
 */
       
#include <cs50.h>
#include <stdio.h>
#include <string.h>

#include "helpers.h"

/**
 * Returns true if value is in array of n values, else false.
 */
bool binarysearch(int value, int values[], int min, int max)
{
        
        int midPoint = (min + max)/2;
        if(value == values[midPoint])
        {
            return true;
        }
        while(min < max)
        {
            
            // if the search value is less then middle point
            if(value < values[midPoint])
            {
                return binarysearch(value, values, midPoint - 1, min);
            }
            // if the search value is greater then middle point
            else if(value > values[midPoint])
            {
                return binarysearch(value, values, midPoint + 1, max);
            }
        }
        
    return false;
}


bool search(int value, int values[], int n)
{
    return binarysearch(value, values, 0, n-1);
}

/**
 * Sorts array of n values.
 */
void sort(int values[], int n)
{
    // TODO: implement an O(n^2) sorting algorithm
 
        for(int i = 0; i < n; i++)
        {
            int nonsorted = 0;
            for(int j = 0; j < n - 1; j++)
        {
            
            // if the first number is greater then the next
            if(values[j] > values[j + 1])
            {
                // we swap one time
                nonsorted++; 
                int temp = values[j];
                values[j] = values[j+1];
                values[j+1] = temp;
            }
            
        }
        // the list is not sorted yet, if we have to swap again
         if(nonsorted > 0)
         {
            continue;
         }
        }
    return;
}
